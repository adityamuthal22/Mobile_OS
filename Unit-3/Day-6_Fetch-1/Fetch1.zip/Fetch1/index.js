function getData() {
    let movie = document.getElementById("movie").value;
  
    const url = ` http://www.omdbapi.com/?s=${movie}&apikey=bf10365b`;
  
    fetch(url)
      .then(function (res) {
        return res.json();
      })
      .then(function (res) {
        append(res);
        console.log(res);
      })
      .catch(function (err) {
        console.log(err);
      });
  }

  function append(data) {
    let container = document.getElementById("container");
  
    // container.innerHTML = null;
  let div =document.createElement("div")
    let title = document.createElement("p");
    title.innerText = `Movie Title: ${data.Search[0].Title}`;
  
    let Year = document.createElement("p");
    Year.innerText = `Date OF Year: ${data.Search[0].Year}`;
  
    let imdbID = document.createElement("p");
    imdbID.innerText = `Movie imdbID: ${data.Search[0].imdbID}`;
  
    let Type = document.createElement("p");
    Type.innerText = `Movie Type: ${data.Search[0].Type}`;
  
    let Poster = document.createElement("img");
    Poster.src = data.Search[0].Poster;
  
    div.append(Poster,title,Year,imdbID,Type);
    container.append(div)
   
  }