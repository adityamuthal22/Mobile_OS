let Amar={
    name:"Amar",
    char:"singer",
  

        relation:function(place){
            console.log(`${this.name} is a ${this.char},lives in a ${place}`);
        },
};

let Akbar={
    name:"Akbar",
    char:"chef",
  
};

let Anthony ={
    name:"Anthony",
    char:"Magician",
    
}

Amar.relation.call(Amar,"Goa");
Amar.relation.call(Akbar,"Mumbai");
Amar.relation.call(Anthony,"Kashmir");